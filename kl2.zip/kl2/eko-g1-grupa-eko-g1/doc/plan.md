Termin realizacji: .09.2018r.
Osoba odpowiedzialna za spójność kodu:

#Etap 1
Przygotowanie grafiki znajdującej się w tle strony - Maja Harkot

#Etap 2
Strona główna - Karolina Biskup

#Etap 3
Zakładka archiwum -

#Etap 4
Zakładka konkursy -

#Etap 5
Zakładka działania -

#Etap 6
Zakładka galerie -

#Etap 7
Zakładka LOP -

#Etap 8
Zakładka kontakt-

#Etap 9
Sprawdzenie kodu i nakładanie poprawek
